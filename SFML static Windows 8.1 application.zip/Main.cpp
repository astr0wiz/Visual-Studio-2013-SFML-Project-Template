#include <SFML/Graphics.hpp>

/*
	==========================================================
	==========================================================
	                SFML STATIC TEMPLATE
					     Windows 8.1
	==========================================================
	==========================================================


	This is the default SFML tester app saved as a template.  
	It should be statically linked.  Also, to maintain 
	compatibility with other platforms (Linux, et.al.), the 
	sfml-main library is added to the Linker->Input property
	list.

	This template will compile in either Debug or Release
	configurations.  Please ensure the SFML API is loaded.
	Instructions for loading SFML are on the SFML site:
	(http://www.sfml-dev.org)

	*************************
	****                 ****
	!!!!    ATTENTION    !!!!
	****                 ****
	*************************
	The SFML location is set using the $(SFML_HOME) macro, 
	which is just the %SFML_HOME% environment variable.  If
	this environment variable is not set, the properties
	directories will be wrong.

	Note that the directory 
	C:\Program Files (x86)\Windows Kits\8.1\Lib\winv6.3\um\x86
	was also added to the library directories to ensure 
	winMM.lib was linked.  The author's development machine
	apparently had a setup problem as that library would not
	load until the absolute directory was added.

	..........................................................

	Date:   January 9, 2015
	Author: James Jensen (astr0wiz)

	..........................................................
	*/

int main()
{
	sf::ContextSettings settings;
	settings.antialiasingLevel = 8;
	sf::RenderWindow window(sf::VideoMode(200, 200), "SFML in Visual Studio", sf::Style::Default, settings);
	sf::CircleShape shape(100.f);
	shape.setFillColor(sf::Color::Green);

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		window.clear();
		window.draw(shape);
		window.display();
	}

	return 0;
}